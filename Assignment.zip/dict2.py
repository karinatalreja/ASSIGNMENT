class KeyNotFound(Exception):
    def __init__(self, key):
        self.key = key

    def __str__(self):
        return f"Key '{self.key}' not found"

class MyDictionary:
    def __init__(self):
        self.keys = []
        self.values = []

    def __getitem__(self, key):
        if key in self.keys:
            pos = self.keys.index(key)
            return self.values[pos]
        else:
            raise KeyNotFound(key)

    def __setitem__(self, key, value):
        if key in self.keys:
            pos = self.keys.index(key)
            self.values[pos] = value
        else:
            self.keys.append(key)
            self.values.append(value)

    def __delitem__(self, key):
        if key in self.keys:
            pos = self.keys.index(key)
            del self.keys[pos]
            del self.values[pos]
        else:
            raise KeyNotFound(key)

    def __contains__(self, key):
        return key in self.keys

    def __len__(self):
        return len(self.keys)

    def keys(self):
        return self.keys

    def values(self):
        return self.values

    def items(self):
        return zip(self.keys, self.values)


