import unittest
from dict2 import MyDictionary, KeyNotFound

class TestMyDictionary(unittest.TestCase):
    def setUp(self):
        self.my_dict = MyDictionary()
        self.my_dict['a'] = 1
        self.my_dict['b'] = 2

    def test_get_existing_key(self):
        self.assertEqual(self.my_dict['a'], 1)

    def test_get_nonexistent_key(self):
        with self.assertRaises(KeyNotFound):
            self.my_dict['c']

    def test_contains_existing_key(self):
        self.assertTrue('a' in self.my_dict)

    def test_contains_nonexistent_key(self):
        self.assertFalse('c' in self.my_dict)

if __name__ == '__main__':
    unittest.main()
